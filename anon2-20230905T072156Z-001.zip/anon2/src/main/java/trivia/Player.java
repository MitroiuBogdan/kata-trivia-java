package trivia;

public class Player {

    private int place;
    private int purse;
    private boolean inPenaltyBox;

    private boolean gettingOutOfPenaltyBox; // TODO victorrentea 2023-09-04: chiar e necesar ?

    private final String playerName;


    public Player(String playerName) {
        // TODO victorrentea 2023-09-04: 0 si false sunt valori default pt tipurile campurilor
        this.place = 0;
        this.purse = 0;
        this.inPenaltyBox = false;
        this.gettingOutOfPenaltyBox = false;
        this.playerName = playerName;
    }

    public int getPlace() {
        return place;
    }

    public int getPurse() {
        return purse;
    }

    public boolean isGettingOutOfPenaltyBox() {
        return gettingOutOfPenaltyBox;
    }

    public void setGettingOutOfPenaltyBox(boolean gettingOutOfPenaltyBox) {
        this.gettingOutOfPenaltyBox = gettingOutOfPenaltyBox;
    }

    public boolean isInPenaltyBox() {
        return inPenaltyBox;
    }


    public String getPlayerName() {
        return playerName;
    }

    @Override
    public String toString() {
        return "Player{" +
                "place=" + place +
                ", purse=" + purse +
                ", inPenaltyBox=" + inPenaltyBox +
                ", playerName='" + playerName + '\'' +
                '}';
    }


    public void setInPenaltyBox(boolean inPenaltyBox) {
        this.inPenaltyBox = inPenaltyBox;
    }


    public void updatePositionOnBoard(int roll) {
        this.place = this.place + roll; // TODO victorrentea 2023-09-04: +=
        if (this.place > 11) { // TODO victorrentea 2023-09-04: >11 inseamna >=12. dar ce INSEAMNA 12?
            this.place = this.place - 12; // TODO victorrentea 2023-09-04: -=
        }
    }

    public void incrementPurseAmount() {
        purse = purse + 1;
    }// TODO victorrentea 2023-09-04: ++

    public boolean hasWon() {
        return !(this.getPurse() == 6);
    }// TODO victorrentea 2023-09-04: apel de getter propriu?
}
