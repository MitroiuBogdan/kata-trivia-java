package trivia;

public enum Category {
    Rock, // TODO victorrentea 2023-09-04: valorile din enumuri sunt mereu UPPERCASE in Java. Daca vrei un string in ele faci ROCK("Rock")
    Science,
    Pop,
    Sports
}
